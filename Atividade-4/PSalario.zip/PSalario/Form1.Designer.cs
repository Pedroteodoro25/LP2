﻿
namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.lblNumeroFilhos = new System.Windows.Forms.Label();
            this.cbxNumeroFilhos = new System.Windows.Forms.ComboBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtNomeFuncionario = new System.Windows.Forms.TextBox();
            this.mskdxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.AliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIR = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescontoIR = new System.Windows.Forms.Label();
            this.lbldescontoINSS = new System.Windows.Forms.Label();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtDescontoINSS = new System.Windows.Forms.TextBox();
            this.txtDescontoIR = new System.Windows.Forms.TextBox();
            this.txtAliquotaIR = new System.Windows.Forms.TextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.txtSalarioLiquido = new System.Windows.Forms.TextBox();
            this.rbdnFeminino = new System.Windows.Forms.RadioButton();
            this.rbdnMasculino = new System.Windows.Forms.RadioButton();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.gbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(25, 35);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(108, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionario";
            this.lblNome.Click += new System.EventHandler(this.lblNome_Click);
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(25, 84);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalarioBruto.TabIndex = 1;
            this.lblSalarioBruto.Text = "Salario Bruto";
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbdnMasculino);
            this.gbxSexo.Controls.Add(this.rbdnFeminino);
            this.gbxSexo.Location = new System.Drawing.Point(565, 69);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(200, 100);
            this.gbxSexo.TabIndex = 2;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // lblNumeroFilhos
            // 
            this.lblNumeroFilhos.AutoSize = true;
            this.lblNumeroFilhos.Location = new System.Drawing.Point(25, 130);
            this.lblNumeroFilhos.Name = "lblNumeroFilhos";
            this.lblNumeroFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblNumeroFilhos.TabIndex = 4;
            this.lblNumeroFilhos.Text = "Numero de Filhos";
            // 
            // cbxNumeroFilhos
            // 
            this.cbxNumeroFilhos.FormattingEnabled = true;
            this.cbxNumeroFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbxNumeroFilhos.Location = new System.Drawing.Point(168, 122);
            this.cbxNumeroFilhos.Name = "cbxNumeroFilhos";
            this.cbxNumeroFilhos.Size = new System.Drawing.Size(121, 21);
            this.cbxNumeroFilhos.TabIndex = 5;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(189, 166);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(140, 70);
            this.btnVerificar.TabIndex = 3;
            this.btnVerificar.Text = "Verificar Descontos ";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtNomeFuncionario
            // 
            this.txtNomeFuncionario.Location = new System.Drawing.Point(180, 32);
            this.txtNomeFuncionario.Name = "txtNomeFuncionario";
            this.txtNomeFuncionario.Size = new System.Drawing.Size(193, 20);
            this.txtNomeFuncionario.TabIndex = 6;
            // 
            // mskdxSalarioBruto
            // 
            this.mskdxSalarioBruto.Location = new System.Drawing.Point(180, 77);
            this.mskdxSalarioBruto.Name = "mskdxSalarioBruto";
            this.mskdxSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.mskdxSalarioBruto.TabIndex = 7;
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Location = new System.Drawing.Point(33, 195);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(59, 13);
            this.lblMensagem.TabIndex = 8;
            this.lblMensagem.Text = "Mensagem";
            this.lblMensagem.Visible = false;
            // 
            // AliquotaINSS
            // 
            this.AliquotaINSS.AutoSize = true;
            this.AliquotaINSS.Location = new System.Drawing.Point(57, 269);
            this.AliquotaINSS.Name = "AliquotaINSS";
            this.AliquotaINSS.Size = new System.Drawing.Size(73, 13);
            this.AliquotaINSS.TabIndex = 9;
            this.AliquotaINSS.Text = "Aliquota INSS";
            // 
            // lblAliquotaIR
            // 
            this.lblAliquotaIR.AutoSize = true;
            this.lblAliquotaIR.Location = new System.Drawing.Point(57, 311);
            this.lblAliquotaIR.Name = "lblAliquotaIR";
            this.lblAliquotaIR.Size = new System.Drawing.Size(59, 13);
            this.lblAliquotaIR.TabIndex = 10;
            this.lblAliquotaIR.Text = "Aliquota IR";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(57, 352);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(74, 13);
            this.lblSalarioFamilia.TabIndex = 11;
            this.lblSalarioFamilia.Text = "Salario Familia";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(57, 400);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioLiquido.TabIndex = 12;
            this.lblSalarioLiquido.Text = "Salario Liquido";
            // 
            // lblDescontoIR
            // 
            this.lblDescontoIR.AutoSize = true;
            this.lblDescontoIR.Location = new System.Drawing.Point(383, 311);
            this.lblDescontoIR.Name = "lblDescontoIR";
            this.lblDescontoIR.Size = new System.Drawing.Size(67, 13);
            this.lblDescontoIR.TabIndex = 13;
            this.lblDescontoIR.Text = "Desconto IR";
            // 
            // lbldescontoINSS
            // 
            this.lbldescontoINSS.AutoSize = true;
            this.lbldescontoINSS.Location = new System.Drawing.Point(383, 269);
            this.lbldescontoINSS.Name = "lbldescontoINSS";
            this.lbldescontoINSS.Size = new System.Drawing.Size(81, 13);
            this.lbldescontoINSS.TabIndex = 13;
            this.lbldescontoINSS.Text = "Desconto INSS";
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Location = new System.Drawing.Point(168, 269);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaINSS.TabIndex = 14;
            // 
            // txtDescontoINSS
            // 
            this.txtDescontoINSS.Location = new System.Drawing.Point(485, 266);
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            this.txtDescontoINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescontoINSS.TabIndex = 15;
            // 
            // txtDescontoIR
            // 
            this.txtDescontoIR.Location = new System.Drawing.Point(485, 304);
            this.txtDescontoIR.Name = "txtDescontoIR";
            this.txtDescontoIR.Size = new System.Drawing.Size(100, 20);
            this.txtDescontoIR.TabIndex = 16;
            // 
            // txtAliquotaIR
            // 
            this.txtAliquotaIR.Location = new System.Drawing.Point(168, 308);
            this.txtAliquotaIR.Name = "txtAliquotaIR";
            this.txtAliquotaIR.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaIR.TabIndex = 17;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Location = new System.Drawing.Point(168, 345);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioFamilia.TabIndex = 18;
            // 
            // txtSalarioLiquido
            // 
            this.txtSalarioLiquido.Location = new System.Drawing.Point(168, 397);
            this.txtSalarioLiquido.Name = "txtSalarioLiquido";
            this.txtSalarioLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioLiquido.TabIndex = 19;
            // 
            // rbdnFeminino
            // 
            this.rbdnFeminino.AutoSize = true;
            this.rbdnFeminino.Checked = true;
            this.rbdnFeminino.Location = new System.Drawing.Point(25, 19);
            this.rbdnFeminino.Name = "rbdnFeminino";
            this.rbdnFeminino.Size = new System.Drawing.Size(67, 17);
            this.rbdnFeminino.TabIndex = 0;
            this.rbdnFeminino.TabStop = true;
            this.rbdnFeminino.Text = "Feminino";
            this.rbdnFeminino.UseVisualStyleBackColor = true;
            // 
            // rbdnMasculino
            // 
            this.rbdnMasculino.AutoSize = true;
            this.rbdnMasculino.Location = new System.Drawing.Point(25, 59);
            this.rbdnMasculino.Name = "rbdnMasculino";
            this.rbdnMasculino.Size = new System.Drawing.Size(73, 17);
            this.rbdnMasculino.TabIndex = 1;
            this.rbdnMasculino.Text = "Masculino";
            this.rbdnMasculino.UseVisualStyleBackColor = true;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(554, 219);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(62, 17);
            this.ckbxCasado.TabIndex = 20;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.txtSalarioLiquido);
            this.Controls.Add(this.txtSalarioFamilia);
            this.Controls.Add(this.txtAliquotaIR);
            this.Controls.Add(this.txtDescontoIR);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.lbldescontoINSS);
            this.Controls.Add(this.lblDescontoIR);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIR);
            this.Controls.Add(this.AliquotaINSS);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.mskdxSalarioBruto);
            this.Controls.Add(this.txtNomeFuncionario);
            this.Controls.Add(this.cbxNumeroFilhos);
            this.Controls.Add(this.lblNumeroFilhos);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.Label lblNumeroFilhos;
        private System.Windows.Forms.ComboBox cbxNumeroFilhos;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtNomeFuncionario;
        private System.Windows.Forms.MaskedTextBox mskdxSalarioBruto;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.Label AliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIR;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoIR;
        private System.Windows.Forms.Label lbldescontoINSS;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtDescontoINSS;
        private System.Windows.Forms.TextBox txtDescontoIR;
        private System.Windows.Forms.TextBox txtAliquotaIR;
        private System.Windows.Forms.TextBox txtSalarioFamilia;
        private System.Windows.Forms.TextBox txtSalarioLiquido;
        private System.Windows.Forms.RadioButton rbdnMasculino;
        private System.Windows.Forms.RadioButton rbdnFeminino;
        private System.Windows.Forms.CheckBox ckbxCasado;
    }
}

