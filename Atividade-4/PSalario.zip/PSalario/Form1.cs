﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lblNome.Visible = true;
            double SalarioBruto = 0;

            if ((txtNomeFuncionario.Text == "") || (txtNomeFuncionario.Text.Length<5))
                 MessageBox.Show("Nome Invalido");
            else if(!double.TryParse(mskdxSalarioBruto.Text,out SalarioBruto))
                MessageBox.Show("Salario Invalido");
            else
            {
                double descontoINSS = 0;
                double descontoIR=0;
                double SalarioFamilia = 0;


                /*           Aliquota INSS para Salario Bruto:
                             Ate 800.47 - 4,65 %
                             De 800.48 a 1050 - 8.65 %
                             De 1050.01 a 1400.77 - 9.00 %
                             De 1400.78 a 2801.56 - 11.00 %
                             > 2801.56 ->Desconto = 308.17(teto)

                 */
                if (SalarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7.65%";
                    descontoINSS = 7.65 / 100 * SalarioBruto;
                }
                else if(SalarioBruto <= 1050)
                {
                    txtAliquotaINSS.Text = "8.65%";
                    descontoINSS = 8.65 / 100 * SalarioBruto;// ou o 0.0865*Salario Bruto
                }
                else if(SalarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9.00%";
                    descontoINSS = 9.00 / 100 * SalarioBruto;
                }
                else if(SalarioBruto <=2801.56)
                {
                    txtAliquotaINSS.Text = "11.00%";
                    descontoINSS = 308.17;
                }

                txtDescontoINSS.Text = descontoINSS.ToString("N2");

                /*
                 Aliquota IRPF para Salario Bruto:
                 Ate 1257.12-isento
                 De 1257.13 a 2512.08 - 15.00%
                 > 2512.08 - 27.5%
                */

                //calculo ir 
                if (SalarioBruto >=1257.12)
                {
                    txtAliquotaIR.Text = "0";
                    descontoIR = 0;
                }
                else if(SalarioBruto <=2512.08)
                {
                    txtAliquotaIR.Text = "15.00%";
                    descontoIR = 15 / 100 * SalarioBruto;
                }
                else if(SalarioBruto<=2512.08)
                {
                    txtAliquotaIR.Text = "27.5%";
                    descontoIR = 27.5 / 100 * SalarioBruto;
                }
                txtDescontoIR.Text = descontoIR.ToString("N2");

                /*
                 Salario Familia para Salario Bruto:
                 Ate 435.52 - 22.33 por filho
                 De 435.53 a 654.61 - 15.74 por filho
                 > 654.61 - 0
                */
                if (SalarioBruto <= 435.52)
                {
                    SalarioFamilia = Convert.ToDouble(cbxNumeroFilhos.SelectedItem) * 22.23;
                    txtSalarioFamilia.Text = SalarioFamilia.ToString();

                }
                else if (SalarioBruto <= 654.61)
                {
                    SalarioFamilia = Convert.ToDouble(cbxNumeroFilhos.SelectedItem) * 15.74;
                    txtSalarioFamilia.Text = SalarioFamilia.ToString();
                }
                 else if (SalarioBruto > 654.61)
                {
                    SalarioFamilia = Convert.ToDouble(cbxNumeroFilhos.SelectedItem) * 0.00;
                    txtSalarioFamilia.Text = SalarioFamilia.ToString();
                }
               


                double SalarioLiquido = 0;

                SalarioLiquido = SalarioBruto - descontoINSS - descontoIR + SalarioFamilia;

                txtSalarioLiquido.Text = SalarioLiquido.ToString();

                //preencher o label
                string texto = "Os Descontos do Salario";

                if (rbdnFeminino.Checked)
                    texto = texto + "da sra. ";
                else
                    texto = texto + "do sr. ";
                if (ckbxCasado.Checked)
                    texto = texto + " que é casado(a)";
                else
                    texto = texto + "que é solteiro(a)";
                texto = texto + "e que tem" + cbxNumeroFilhos.SelectedItem.ToString() +
                    "filho(s)";
               



            }


        }
    }
}
