﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjPesoAtual1
{
   
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            BtnCalcular.Enabled = true ;
        }

       
        private void txtAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            BtnCalcular.Enabled = txtAltura.Text != "" ? true : false;
        }

        //=====================================================
        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double.TryParse(txtAltura.Text, out double altura);
            if (altura == null) return;

            //executar os calculos
            double peso_ideal = 0;
             
            //condiçao masculino ou feminino
            if(radMasculino.Checked)
            {
                //masculino
                peso_ideal = (72.7 * altura) - 58;
            }
            else
            {
                //feminino
                peso_ideal = (62.1 * altura) - 44.7;
            }
            StringBuilder str = new StringBuilder("Peso ideal:" + peso_ideal.ToString("0.00") + "Kg.");

            //comparaçao com o peso atual
            if (txtPeso.Text != "")
            {
                double.TryParse(txtPeso.Text, out double peso_atual);
                if (peso_atual != null)
                {
                    if (peso_ideal < peso_atual)
                    {
                        //Regime Obrigatorio Já
                        str.Append(Environment.NewLine + "Regime Obrigatorio Já" + (peso_atual - peso_ideal).ToString("0.00")+"kg.");
                    }
                    else if (peso_ideal > peso_atual)
                    {
                        //coma bastante massas e doces
                        str.Append(Environment.NewLine + "coma bastante massas e doces ") + (peso_atual - peso_ideal).ToString("0.00") + "kg.";) ; 
                    }

                

                else
                {
                    //tem o peso idel
                    str.Append(Environment.NewLine + "Voce está com o peso ideal");
                }
                }
            }

            MessageBox.Show(str.ToString());
        }
    }
}
