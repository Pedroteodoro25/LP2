﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void frmHorista_Load(object sender, EventArgs e)
        {

        }

        private void btnIstanciarHorista_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            //set
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtSalarioHora.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFaltas.Text);
            //get
            MessageBox.Show("Nome:" + objHorista.NomeEmpregado +
                            "\n" + "Matricula:" + objHorista.Matricula + "\n" +
                            "TempoTrabalhado:" + objHorista.TempoTrabalho().ToString()
                            + "\n" + "Salario:" + objHorista.SalarioBruto().ToString("N2"));





        }
    }
}
