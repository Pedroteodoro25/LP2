﻿
namespace Pclasses
{
    partial class txtMatricula
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblDataEntrada = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtDataEntrada = new System.Windows.Forms.TextBox();
            this.BtnInstanciarMensalista = new System.Windows.Forms.Button();
            this.BtnInstanciarMensalistaParametros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(68, 33);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(77, 18);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(68, 89);
            this.lblNome.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(53, 18);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(68, 132);
            this.lblSalarioMensal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(120, 18);
            this.lblSalarioMensal.TabIndex = 2;
            this.lblSalarioMensal.Text = "Salario Mensal";
            // 
            // lblDataEntrada
            // 
            this.lblDataEntrada.AutoSize = true;
            this.lblDataEntrada.Location = new System.Drawing.Point(68, 179);
            this.lblDataEntrada.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDataEntrada.Name = "lblDataEntrada";
            this.lblDataEntrada.Size = new System.Drawing.Size(201, 18);
            this.lblDataEntrada.TabIndex = 3;
            this.lblDataEntrada.Text = "Data Entrada na Empresa";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(296, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 24);
            this.textBox1.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(296, 83);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 24);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(296, 126);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(100, 24);
            this.txtSalarioMensal.TabIndex = 6;
            // 
            // txtDataEntrada
            // 
            this.txtDataEntrada.Location = new System.Drawing.Point(296, 179);
            this.txtDataEntrada.Name = "txtDataEntrada";
            this.txtDataEntrada.Size = new System.Drawing.Size(100, 24);
            this.txtDataEntrada.TabIndex = 7;
            // 
            // BtnInstanciarMensalista
            // 
            this.BtnInstanciarMensalista.Location = new System.Drawing.Point(71, 253);
            this.BtnInstanciarMensalista.Name = "BtnInstanciarMensalista";
            this.BtnInstanciarMensalista.Size = new System.Drawing.Size(156, 85);
            this.BtnInstanciarMensalista.TabIndex = 8;
            this.BtnInstanciarMensalista.Text = "Instanciar Mensalista";
            this.BtnInstanciarMensalista.UseVisualStyleBackColor = true;
            this.BtnInstanciarMensalista.Click += new System.EventHandler(this.BtnInstanciarMensalista_Click);
            // 
            // BtnInstanciarMensalistaParametros
            // 
            this.BtnInstanciarMensalistaParametros.Location = new System.Drawing.Point(316, 253);
            this.BtnInstanciarMensalistaParametros.Name = "BtnInstanciarMensalistaParametros";
            this.BtnInstanciarMensalistaParametros.Size = new System.Drawing.Size(156, 85);
            this.BtnInstanciarMensalistaParametros.TabIndex = 9;
            this.BtnInstanciarMensalistaParametros.Text = "Instanciar Mensalista passando parametros";
            this.BtnInstanciarMensalistaParametros.UseVisualStyleBackColor = true;
            this.BtnInstanciarMensalistaParametros.Click += new System.EventHandler(this.BtnInstanciarMensalistaParametros_Click);
            // 
            // txtMatricula
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 623);
            this.Controls.Add(this.BtnInstanciarMensalistaParametros);
            this.Controls.Add(this.BtnInstanciarMensalista);
            this.Controls.Add(this.txtDataEntrada);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblDataEntrada);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "txtMatricula";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblDataEntrada;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtDataEntrada;
        private System.Windows.Forms.Button BtnInstanciarMensalista;
        private System.Windows.Forms.Button BtnInstanciarMensalistaParametros;
    }
}