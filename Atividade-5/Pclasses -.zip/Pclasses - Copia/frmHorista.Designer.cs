﻿
namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNumeroHoras = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNumeroHoras = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtDiasFaltas = new System.Windows.Forms.TextBox();
            this.lblDataEntEMpresa = new System.Windows.Forms.Label();
            this.lblDiasFaltas = new System.Windows.Forms.Label();
            this.btnIstanciarHorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(64, 32);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(72, 19);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(64, 91);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(50, 19);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Location = new System.Drawing.Point(64, 143);
            this.lblSalarioHora.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(122, 19);
            this.lblSalarioHora.TabIndex = 2;
            this.lblSalarioHora.Text = "Salario por Hora";
            // 
            // lblNumeroHoras
            // 
            this.lblNumeroHoras.AutoSize = true;
            this.lblNumeroHoras.Location = new System.Drawing.Point(64, 194);
            this.lblNumeroHoras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumeroHoras.Name = "lblNumeroHoras";
            this.lblNumeroHoras.Size = new System.Drawing.Size(129, 19);
            this.lblNumeroHoras.TabIndex = 3;
            this.lblNumeroHoras.Text = "Numero de Horas";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(215, 29);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(150, 24);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(215, 86);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(150, 24);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(215, 138);
            this.txtSalarioHora.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(150, 24);
            this.txtSalarioHora.TabIndex = 6;
            // 
            // txtNumeroHoras
            // 
            this.txtNumeroHoras.Location = new System.Drawing.Point(215, 194);
            this.txtNumeroHoras.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNumeroHoras.Name = "txtNumeroHoras";
            this.txtNumeroHoras.Size = new System.Drawing.Size(150, 24);
            this.txtNumeroHoras.TabIndex = 7;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(265, 233);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 24);
            this.txtData.TabIndex = 8;
            // 
            // txtDiasFaltas
            // 
            this.txtDiasFaltas.Location = new System.Drawing.Point(215, 280);
            this.txtDiasFaltas.Name = "txtDiasFaltas";
            this.txtDiasFaltas.Size = new System.Drawing.Size(150, 24);
            this.txtDiasFaltas.TabIndex = 9;
            // 
            // lblDataEntEMpresa
            // 
            this.lblDataEntEMpresa.AutoSize = true;
            this.lblDataEntEMpresa.Location = new System.Drawing.Point(64, 233);
            this.lblDataEntEMpresa.Name = "lblDataEntEMpresa";
            this.lblDataEntEMpresa.Size = new System.Drawing.Size(176, 19);
            this.lblDataEntEMpresa.TabIndex = 10;
            this.lblDataEntEMpresa.Text = "Data Entrada na Empresa";
            // 
            // lblDiasFaltas
            // 
            this.lblDiasFaltas.AutoSize = true;
            this.lblDiasFaltas.Location = new System.Drawing.Point(76, 280);
            this.lblDiasFaltas.Name = "lblDiasFaltas";
            this.lblDiasFaltas.Size = new System.Drawing.Size(100, 19);
            this.lblDiasFaltas.TabIndex = 11;
            this.lblDiasFaltas.Text = "Dias de Faltas";
            // 
            // btnIstanciarHorista
            // 
            this.btnIstanciarHorista.Location = new System.Drawing.Point(143, 344);
            this.btnIstanciarHorista.Name = "btnIstanciarHorista";
            this.btnIstanciarHorista.Size = new System.Drawing.Size(185, 45);
            this.btnIstanciarHorista.TabIndex = 12;
            this.btnIstanciarHorista.Text = "Instanciar Horista";
            this.btnIstanciarHorista.UseVisualStyleBackColor = true;
            this.btnIstanciarHorista.Click += new System.EventHandler(this.btnIstanciarHorista_Click);
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 658);
            this.Controls.Add(this.btnIstanciarHorista);
            this.Controls.Add(this.lblDiasFaltas);
            this.Controls.Add(this.lblDataEntEMpresa);
            this.Controls.Add(this.txtDiasFaltas);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtNumeroHoras);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblNumeroHoras);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.Load += new System.EventHandler(this.frmHorista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNumeroHoras;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNumeroHoras;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtDiasFaltas;
        private System.Windows.Forms.Label lblDataEntEMpresa;
        private System.Windows.Forms.Label lblDiasFaltas;
        private System.Windows.Forms.Button btnIstanciarHorista;
    }
}